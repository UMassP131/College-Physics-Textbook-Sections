This ZIP file contains the complete contents of a module.  

TO VIEW THE MODULE IN YOUR BROWSER:
=================================== 
Open the start.html file for viewing the module's contents.  A navigation panel will be located on the left hand side.

INCLUDED FILES 
==============
HTML pages of the module's contents:
- start.html - A shortcut for viewing the module's contents in a set of frames.
- content/cover.html and cover.png - Module cover page and image file.
- content/index.html - Module title page.
- content/bk01-toc.html - Module table of contents.
- content/pr01.html - The module's contents.

Other support and advanced files:
- content/content.css - Primary CSS file for styling the HTML files.
- content/offline-zip-overrides.css - An additional CSS file for styling the HTML files.
- content/index.cnxml - The original XML source code representing the contents and metadata of the module, written in CNXML.
- content/index_auto_generated.cnxml - A read-only version of the module XML file that has been upgraded to the latest version of CNXML and that includes extended metadata.
- content/index.dbk - The index.cnxml file converted into a standalone Docbook file format.
- content/index.included.dbk - The index.cnxml file converted into a Docbook format that would be used for inclusion in a collection.
- content/mXXXXX.idXXXXXX.svg and mXXXXX.idXXXXXX.png - Math is automatically converted to these image formats for browsers that do not support MathML. 
- Various media files - Images, videos, applets, audio recordings, etc., used in the module.  These will only appear if they are part of the module.
